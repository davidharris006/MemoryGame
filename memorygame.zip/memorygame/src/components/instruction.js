import React from "react";

function Instructions(props) {
    return (
    <div id="instructiondiv" class="container-fluid">
        <div class="jumbotorn" id="instructions">

    <div id="clickytext"> 
        <h1>CLICKY GAME!!!</h1>
    </div>

    <div id="instrucitontext">
            <h2>Click an image to get points,</h2><h2> but dont click any images that you already clicked.</h2>
    </div>
        </div>
    </div>
    );
}


export default Instructions;